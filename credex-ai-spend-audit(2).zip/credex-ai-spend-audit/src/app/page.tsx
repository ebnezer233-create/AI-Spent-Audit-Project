"use client";
import { useState } from "react";
import { SpendForm } from "@/components/SpendForm";
import { Results } from "@/components/Results";
import { runAudit } from "@/lib/auditEngine";
import { AuditInput, AuditResult } from "@/types";

export default function Home() {
  const [result, setResult] = useState<AuditResult | null>(null);
  async function handleAudit(input: AuditInput) {
    const initial = runAudit(input);
    setResult(initial);
    fetch("/api/audit", { method:"POST", headers:{"content-type":"application/json"}, body: JSON.stringify(input) })
      .then(r => r.ok ? r.json() : initial)
      .then(setResult)
      .catch(() => setResult(initial));
  }
  return <main className="mx-auto max-w-6xl px-4 py-10">
    <nav className="mb-12 flex items-center justify-between"><p className="font-black">AI Spend Scout</p><a className="text-sm text-emerald-300" href="#audit">Run audit</a></nav>
    <section className="mb-10 text-center">
      <p className="mx-auto mb-4 w-fit rounded-full bg-emerald-400/10 px-4 py-2 text-sm text-emerald-200">Free AI subscription audit for startup teams</p>
      <h1 className="text-5xl font-black tracking-tight md:text-7xl">Stop overpaying for AI tools.</h1>
      <p className="mx-auto mt-5 max-w-2xl text-lg text-slate-300">Enter your AI stack and get an instant, shareable audit showing plan fit, cheaper alternatives, and estimated monthly savings.</p>
    </section>
    <div id="audit"><SpendForm onResult={handleAudit} /></div>
    {result && <Results result={result} />}
  </main>;
}
