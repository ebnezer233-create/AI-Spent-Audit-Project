import type { Metadata } from "next";
import { supabase } from "@/lib/storage";
import { Results } from "@/components/Results";
import { notFound } from "next/navigation";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  return {
    title: `AI Spend Audit ${slug}`,
    description: "Public AI spend audit result",
    openGraph: { title: "AI Spend Audit Result", description: "See potential AI tool savings.", type: "article" },
    twitter: { card: "summary_large_image", title: "AI Spend Audit Result", description: "See potential AI tool savings." }
  };
}

export default async function AuditPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (!supabase) return <main className="mx-auto max-w-3xl p-10"><h1 className="text-3xl font-bold">Public audit URL</h1><p className="mt-4 text-slate-300">Connect Supabase to load saved public audits. Slug: {slug}</p></main>;
  const { data } = await supabase.from("audits").select("result_json").eq("slug", slug).single();
  if (!data) notFound();
  return <main className="mx-auto max-w-6xl px-4 py-10"><Results result={data.result_json} /></main>;
}
