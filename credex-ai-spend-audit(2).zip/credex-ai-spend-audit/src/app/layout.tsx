import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "AI Spend Scout",
  description: "Find wasted AI tool spend in minutes.",
  openGraph: { title: "AI Spend Scout", description: "Audit your AI subscriptions and uncover savings.", type: "website" },
  twitter: { card: "summary_large_image", title: "AI Spend Scout", description: "Audit AI spend instantly." }
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
