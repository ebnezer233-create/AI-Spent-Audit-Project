import { NextRequest, NextResponse } from "next/server";
import { runAudit } from "@/lib/auditEngine";
import { generateSummary } from "@/lib/llm";
import { saveAudit } from "@/lib/storage";
import { AuditInput } from "@/types";

export async function POST(req: NextRequest) {
  const input = await req.json() as AuditInput;
  const initial = runAudit(input);
  const summary = await generateSummary(input, initial.totalMonthlySavings);
  const result = runAudit(input, summary);
  await saveAudit(result);
  return NextResponse.json(result);
}
