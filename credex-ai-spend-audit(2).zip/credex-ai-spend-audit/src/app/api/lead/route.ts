import { NextRequest, NextResponse } from "next/server";
import { Resend } from "resend";
import { supabase } from "@/lib/storage";

export async function POST(req: NextRequest) {
  const form = await req.formData();
  const email = String(form.get("email") || "");
  if (!email.includes("@")) return NextResponse.json({ error: "Invalid email" }, { status: 400 });
  const lead = {
    email,
    company: String(form.get("company") || ""),
    role: String(form.get("role") || ""),
    audit_id: String(form.get("auditId") || "")
  };
  if (supabase) await supabase.from("leads").insert(lead);
  if (process.env.RESEND_API_KEY) {
    const resend = new Resend(process.env.RESEND_API_KEY);
    await resend.emails.send({
      from: process.env.FROM_EMAIL || "AI Spend Scout <audit@example.com>",
      to: email,
      subject: "Your AI Spend Audit",
      text: "Thanks for running your audit. If your savings opportunity is significant, Credex can help capture more savings through discounted AI credits."
    });
  }
  return NextResponse.redirect(new URL("/?captured=1", req.url));
}
