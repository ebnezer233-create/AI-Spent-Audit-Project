export type UseCase = "coding" | "writing" | "data" | "research" | "mixed";
export type ToolName =
  | "Cursor" | "GitHub Copilot" | "Claude" | "ChatGPT" | "Anthropic API direct"
  | "OpenAI API direct" | "Gemini" | "Windsurf";

export type ToolInput = {
  id: string;
  tool: ToolName;
  plan: string;
  monthlySpend: number;
  seats: number;
};

export type AuditInput = {
  teamSize: number;
  useCase: UseCase;
  tools: ToolInput[];
};

export type Recommendation = {
  tool: ToolName;
  plan: string;
  currentSpend: number;
  recommendedAction: string;
  recommendedSpend: number;
  monthlySavings: number;
  annualSavings: number;
  reason: string;
  severity: "optimal" | "minor" | "major";
};

export type AuditResult = {
  id: string;
  createdAt: string;
  input: AuditInput;
  recommendations: Recommendation[];
  totalMonthlySavings: number;
  totalAnnualSavings: number;
  summary: string;
  publicSlug: string;
};
