import { describe, expect, it } from "vitest";
import { runAudit } from "./auditEngine";
import { AuditInput } from "@/types";

const base = (tools: AuditInput["tools"]): AuditInput => ({ teamSize: 2, useCase: "coding", tools });

describe("audit engine", () => {
  it("downgrades Cursor Business for a tiny team", () => {
    const r = runAudit(base([{ id:"1", tool:"Cursor", plan:"Business", monthlySpend:80, seats:2 }]));
    expect(r.totalMonthlySavings).toBe(40);
  });
  it("does not manufacture savings for good spend", () => {
    const r = runAudit(base([{ id:"1", tool:"Cursor", plan:"Pro", monthlySpend:20, seats:1 }]));
    expect(r.totalMonthlySavings).toBe(0);
  });
  it("recommends Copilot Business over Enterprise for small teams", () => {
    const r = runAudit(base([{ id:"1", tool:"GitHub Copilot", plan:"Enterprise", monthlySpend:78, seats:2 }]));
    expect(r.totalMonthlySavings).toBe(40);
  });
  it("downgrades Claude Max when not research-heavy", () => {
    const r = runAudit(base([{ id:"1", tool:"Claude", plan:"Max", monthlySpend:100, seats:1 }]));
    expect(r.totalMonthlySavings).toBe(80);
  });
  it("flags large API spend for optimization and credits", () => {
    const r = runAudit({ teamSize: 10, useCase: "mixed", tools: [{ id:"1", tool:"OpenAI API direct", plan:"API direct", monthlySpend:1000, seats:1 }] });
    expect(r.totalMonthlySavings).toBe(250);
  });
});
