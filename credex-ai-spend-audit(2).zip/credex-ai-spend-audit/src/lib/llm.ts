import Anthropic from "@anthropic-ai/sdk";
import { AuditInput } from "@/types";
import { fallbackSummary } from "./auditEngine";

export async function generateSummary(input: AuditInput, totalSavings: number) {
  if (!process.env.ANTHROPIC_API_KEY) return fallbackSummary(totalSavings, input.teamSize, input.useCase);
  try {
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const msg = await client.messages.create({
      model: process.env.ANTHROPIC_MODEL || "claude-3-5-haiku-latest",
      max_tokens: 180,
      temperature: 0.4,
      messages: [{
        role: "user",
        content: `Write a concise ~100-word AI spend audit summary for a ${input.teamSize}-person team using AI mostly for ${input.useCase}. Monthly savings estimate: $${totalSavings}. Tools: ${input.tools.map(t => `${t.tool} ${t.plan} $${t.monthlySpend}/mo ${t.seats} seats`).join("; ")}. Be specific, finance-literate, and honest. Do not invent numbers.`
      }]
    });
    const text = msg.content[0]?.type === "text" ? msg.content[0].text : "";
    return text || fallbackSummary(totalSavings, input.teamSize, input.useCase);
  } catch {
    return fallbackSummary(totalSavings, input.teamSize, input.useCase);
  }
}
