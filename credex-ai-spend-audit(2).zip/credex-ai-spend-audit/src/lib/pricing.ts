import { ToolName } from "@/types";

export type Plan = { price: number | null; unit: "seat" | "account" | "usage" | "custom"; notes: string };

export const PRICING: Record<ToolName, Record<string, Plan>> = {
  "Cursor": {
    "Hobby": { price: 0, unit: "account", notes: "Free individual plan" },
    "Pro": { price: 20, unit: "account", notes: "Individual paid plan" },
    "Business": { price: 40, unit: "seat", notes: "Team controls and analytics" },
    "Enterprise": { price: null, unit: "custom", notes: "Custom enterprise pricing" }
  },
  "GitHub Copilot": {
    "Individual": { price: 10, unit: "seat", notes: "Individual Pro monthly" },
    "Business": { price: 19, unit: "seat", notes: "Org policy controls" },
    "Enterprise": { price: 39, unit: "seat", notes: "Enterprise features and higher governance" }
  },
  "Claude": {
    "Free": { price: 0, unit: "account", notes: "Free tier" },
    "Pro": { price: 20, unit: "seat", notes: "Power individual user" },
    "Max": { price: 100, unit: "seat", notes: "Heavy individual usage" },
    "Team": { price: 30, unit: "seat", notes: "Collaboration plan; assumes monthly seat price" },
    "Enterprise": { price: null, unit: "custom", notes: "Custom pricing" },
    "API direct": { price: null, unit: "usage", notes: "Token-based usage" }
  },
  "ChatGPT": {
    "Plus": { price: 20, unit: "seat", notes: "Individual paid plan" },
    "Team": { price: 25, unit: "seat", notes: "Business monthly equivalent, annual-billed public price" },
    "Enterprise": { price: null, unit: "custom", notes: "Custom enterprise pricing" },
    "API direct": { price: null, unit: "usage", notes: "Token-based usage" }
  },
  "Anthropic API direct": {
    "API direct": { price: null, unit: "usage", notes: "Token-based usage" }
  },
  "OpenAI API direct": {
    "API direct": { price: null, unit: "usage", notes: "Token-based usage" }
  },
  "Gemini": {
    "Pro": { price: 19.99, unit: "seat", notes: "Google AI Pro" },
    "Ultra": { price: 249.99, unit: "seat", notes: "Google AI Ultra" },
    "API": { price: null, unit: "usage", notes: "Token-based usage" }
  },
  "Windsurf": {
    "Free": { price: 0, unit: "account", notes: "Free individual plan" },
    "Pro": { price: 20, unit: "seat", notes: "Self-serve paid plan assumption" },
    "Teams": { price: 40, unit: "seat", notes: "Team collaboration plan assumption" },
    "Enterprise": { price: null, unit: "custom", notes: "Custom enterprise pricing" }
  }
};

export const PLANS = Object.fromEntries(Object.entries(PRICING).map(([tool, plans]) => [tool, Object.keys(plans)])) as Record<ToolName, string[]>;
