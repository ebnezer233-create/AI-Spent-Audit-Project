import { createClient } from "@supabase/supabase-js";
import { AuditResult } from "@/types";

export const supabase = process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY
  ? createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY)
  : null;

export async function saveAudit(result: AuditResult) {
  if (!supabase) return { offline: true };
  const publicPayload = {
    slug: result.publicSlug,
    total_monthly_savings: result.totalMonthlySavings,
    total_annual_savings: result.totalAnnualSavings,
    result_json: result
  };
  return supabase.from("audits").insert(publicPayload);
}
