import { AuditInput, AuditResult, Recommendation, ToolInput } from "@/types";
import { PRICING } from "./pricing";

const uid = () => Math.random().toString(36).slice(2, 10);

function planCost(t: ToolInput): number {
  const plan = PRICING[t.tool]?.[t.plan];
  if (!plan || plan.price === null) return t.monthlySpend;
  if (plan.unit === "account") return plan.price;
  if (plan.unit === "seat") return plan.price * Math.max(1, t.seats);
  return t.monthlySpend;
}

function recForTool(t: ToolInput, teamSize: number, useCase: string): Recommendation {
  const expected = planCost(t);
  let recommendedSpend = Math.min(t.monthlySpend, expected || t.monthlySpend);
  let action = "Keep current plan";
  let reason = "Your spend is close to public pricing and the plan appears matched to your team size.";
  let severity: Recommendation["severity"] = "optimal";

  if (t.tool === "Cursor" && ["Business", "Enterprise"].includes(t.plan) && teamSize <= 3) {
    recommendedSpend = 20 * Math.max(1, t.seats);
    action = "Downgrade to Cursor Pro unless you need SSO, central billing, or org analytics";
    reason = "For a very small team, Business features are usually governance overhead; Pro keeps core coding capability at about $20/user.";
  }

  if (t.tool === "GitHub Copilot" && t.plan === "Enterprise" && teamSize < 25) {
    recommendedSpend = 19 * Math.max(1, t.seats);
    action = "Move Copilot Enterprise seats to Business";
    reason = "Enterprise is mainly justified by larger-company governance. Smaller teams often only need Business policy controls.";
  }

  if (t.tool === "ChatGPT" && t.plan === "Team" && t.seats <= 2) {
    recommendedSpend = 20 * t.seats;
    action = "Use ChatGPT Plus seats until collaboration/admin needs are real";
    reason = "For one or two users, Team can be more than needed if shared workspaces and admin controls are not used.";
  }

  if (t.tool === "Claude" && t.plan === "Max" && useCase !== "research" && useCase !== "mixed") {
    recommendedSpend = 20 * Math.max(1, t.seats);
    action = "Downgrade Claude Max to Pro";
    reason = "Max is best for heavy long-context workflows. For normal writing/coding, Pro is usually the defensible starting point.";
  }

  if ((t.tool === "OpenAI API direct" || t.tool === "Anthropic API direct" || t.tool === "Gemini") && t.monthlySpend > 500) {
    recommendedSpend = Math.round(t.monthlySpend * 0.75);
    action = "Review model mix, caching, batching, and discounted credit procurement";
    reason = "High API spend usually has optimization levers: smaller models for routine tasks, prompt caching, batch jobs, and credit purchasing.";
  }

  if (t.monthlySpend > 0 && recommendedSpend < t.monthlySpend) {
    const savings = Math.max(0, Math.round((t.monthlySpend - recommendedSpend) * 100) / 100);
    severity = savings >= 250 ? "major" : "minor";
    return {
      tool: t.tool, plan: t.plan, currentSpend: t.monthlySpend, recommendedAction: action,
      recommendedSpend, monthlySavings: savings, annualSavings: savings * 12, reason, severity
    };
  }

  return {
    tool: t.tool, plan: t.plan, currentSpend: t.monthlySpend, recommendedAction: action,
    recommendedSpend: t.monthlySpend, monthlySavings: 0, annualSavings: 0, reason, severity
  };
}

export function runAudit(input: AuditInput, summary = ""): AuditResult {
  const recommendations = input.tools.map((tool) => recForTool(tool, input.teamSize, input.useCase));
  const totalMonthlySavings = recommendations.reduce((s, r) => s + r.monthlySavings, 0);
  const totalAnnualSavings = totalMonthlySavings * 12;
  const id = uid();
  return {
    id,
    createdAt: new Date().toISOString(),
    input,
    recommendations,
    totalMonthlySavings,
    totalAnnualSavings,
    publicSlug: id,
    summary: summary || fallbackSummary(totalMonthlySavings, input.teamSize, input.useCase)
  };
}

export function fallbackSummary(totalMonthlySavings: number, teamSize: number, useCase: string): string {
  if (totalMonthlySavings >= 500) {
    return `Your ${teamSize}-person team has a meaningful AI spend optimization opportunity. The biggest wins appear to come from right-sizing plans, separating individual productivity tools from team governance tools, and reviewing API usage for caching or credit-based savings.`;
  }
  if (totalMonthlySavings < 100) {
    return `Your ${teamSize}-person team is already spending fairly efficiently for a ${useCase} workflow. Keep monitoring plan changes and API usage, but there is no need to force a downgrade that could slow the team down.`;
  }
  return `Your audit found practical savings without cutting important capability. The best next step is to downgrade underused seats, keep premium tools only where they map to real usage, and revisit API usage monthly.`;
}
