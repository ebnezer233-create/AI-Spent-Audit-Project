"use client";
import { AuditResult } from "@/types";

export function Results({ result }: { result: AuditResult }) {
  const high = result.totalMonthlySavings > 500;
  const low = result.totalMonthlySavings < 100;
  return <section className="mt-8 rounded-3xl bg-white p-6 text-slate-950 shadow-2xl">
    <div className="grid gap-4 md:grid-cols-3">
      <div className="md:col-span-2">
        <p className="text-sm font-semibold uppercase text-emerald-700">Instant audit result</p>
        <h2 className="mt-2 text-4xl font-black">${result.totalMonthlySavings}/mo potential savings</h2>
        <p className="text-xl text-slate-600">${result.totalAnnualSavings}/year annualized savings</p>
      </div>
      <div className="rounded-2xl bg-slate-950 p-4 text-white">
        <p className="font-semibold">{high ? "Credex opportunity" : low ? "Healthy spend" : "Optimization found"}</p>
        <p className="mt-2 text-sm text-slate-300">{high ? "Your savings are large enough to justify a discounted-credit consultation." : low ? "You’re spending well. Sign up for future pricing alerts." : "Capture the report and revisit monthly."}</p>
      </div>
    </div>
    <p className="mt-6 rounded-2xl bg-emerald-50 p-4 text-slate-800">{result.summary}</p>
    <div className="mt-6 overflow-x-auto"><table className="w-full text-left text-sm"><thead><tr className="border-b"><th className="py-2">Tool</th><th>Current</th><th>Action</th><th>Savings</th><th>Reason</th></tr></thead><tbody>{result.recommendations.map((r,i)=><tr className="border-b align-top" key={i}><td className="py-3 font-semibold">{r.tool}<br/><span className="text-slate-500">{r.plan}</span></td><td>${r.currentSpend}/mo</td><td>{r.recommendedAction}</td><td className="font-bold">${r.monthlySavings}/mo</td><td>{r.reason}</td></tr>)}</tbody></table></div>
    <form className="mt-6 grid gap-3 rounded-2xl bg-slate-100 p-4 md:grid-cols-4" action="/api/lead" method="post">
      <input type="hidden" name="auditId" value={result.id} />
      <input className="rounded-xl border p-3" name="email" type="email" required placeholder="Work email" />
      <input className="rounded-xl border p-3" name="company" placeholder="Company optional" />
      <input className="rounded-xl border p-3" name="role" placeholder="Role optional" />
      <button className="rounded-xl bg-slate-950 p-3 font-semibold text-white">Capture report</button>
    </form>
    <p className="mt-4 text-sm text-slate-500">Public share URL: /audit/{result.publicSlug}</p>
  </section>;
}
