"use client";
import { useEffect, useMemo, useState } from "react";
import { PLANS } from "@/lib/pricing";
import { AuditInput, ToolInput, ToolName, UseCase } from "@/types";

const tools = Object.keys(PLANS) as ToolName[];
const emptyTool = (): ToolInput => ({ id: crypto.randomUUID(), tool: "Cursor", plan: "Pro", monthlySpend: 20, seats: 1 });

export function SpendForm({ onResult }: { onResult: (data: AuditInput) => void }) {
  const [teamSize, setTeamSize] = useState(3);
  const [useCase, setUseCase] = useState<UseCase>("coding");
  const [rows, setRows] = useState<ToolInput[]>([emptyTool()]);
  const [hp, setHp] = useState("");

  useEffect(() => {
    const saved = localStorage.getItem("ai-spend-scout");
    if (saved) {
      const parsed = JSON.parse(saved);
      setTeamSize(parsed.teamSize ?? 3); setUseCase(parsed.useCase ?? "coding"); setRows(parsed.tools ?? [emptyTool()]);
    }
  }, []);

  useEffect(() => localStorage.setItem("ai-spend-scout", JSON.stringify({ teamSize, useCase, tools: rows })), [teamSize, useCase, rows]);

  const total = useMemo(() => rows.reduce((s, r) => s + Number(r.monthlySpend || 0), 0), [rows]);

  const update = (id: string, patch: Partial<ToolInput>) => setRows(rows.map(r => {
    if (r.id !== id) return r;
    const next = { ...r, ...patch };
    if (patch.tool) next.plan = PLANS[patch.tool][0];
    return next;
  }));

  return <section className="rounded-3xl border border-white/10 bg-white/10 p-6 shadow-2xl">
    <div className="mb-6 grid gap-4 md:grid-cols-3">
      <label className="grid gap-2">Team size<input className="rounded-xl p-3" type="number" min={1} value={teamSize} onChange={e=>setTeamSize(+e.target.value)} /></label>
      <label className="grid gap-2">Primary use case<select className="rounded-xl p-3" value={useCase} onChange={e=>setUseCase(e.target.value as UseCase)}>{["coding","writing","data","research","mixed"].map(x=><option key={x}>{x}</option>)}</select></label>
      <div className="rounded-2xl bg-slate-900 p-4"><p className="text-sm text-slate-400">Current monthly spend</p><p className="text-3xl font-bold">${total}</p></div>
    </div>
    <input className="hidden" value={hp} onChange={e=>setHp(e.target.value)} tabIndex={-1} autoComplete="off" />
    <div className="space-y-4">{rows.map(row => <div key={row.id} className="grid gap-3 rounded-2xl bg-white p-4 text-slate-950 md:grid-cols-5">
      <select className="rounded-xl border p-3" value={row.tool} onChange={e=>update(row.id,{tool:e.target.value as ToolName})}>{tools.map(t=><option key={t}>{t}</option>)}</select>
      <select className="rounded-xl border p-3" value={row.plan} onChange={e=>update(row.id,{plan:e.target.value})}>{PLANS[row.tool].map(p=><option key={p}>{p}</option>)}</select>
      <input className="rounded-xl border p-3" type="number" min={0} value={row.monthlySpend} onChange={e=>update(row.id,{monthlySpend:+e.target.value})} placeholder="Monthly spend" />
      <input className="rounded-xl border p-3" type="number" min={1} value={row.seats} onChange={e=>update(row.id,{seats:+e.target.value})} placeholder="Seats" />
      <button className="rounded-xl bg-slate-200 p-3" onClick={()=>setRows(rows.filter(r=>r.id!==row.id))} type="button">Remove</button>
    </div>)}</div>
    <div className="mt-6 flex flex-wrap gap-3">
      <button className="rounded-xl bg-white px-5 py-3 font-semibold text-slate-950" type="button" onClick={()=>setRows([...rows, emptyTool()])}>Add tool</button>
      <button className="rounded-xl bg-emerald-400 px-5 py-3 font-semibold text-slate-950" type="button" onClick={()=> hp ? null : onResult({teamSize, useCase, tools: rows})}>Run free audit</button>
    </div>
  </section>;
}
